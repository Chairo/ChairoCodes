<?php
/* Set this variable to true to enable debug output. */
$debug = false;
?>
<html>
<head>
<title>Network Query Tool</title>
<meta name="keywords" content="network query tool, nqt, drunkwerks">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="javascript" type="text/javascript">
<!--
function m(el) {
  if (el.defaultValue==el.value) el.value = ""
}
-->
</script>
</head>

<body bgcolor="#FFFFFF">
<div align="center"> 
  <h2>Network Query Tool</h2>
  <form method="post" action="<?=$_SERVER['PHP_SELF']?>">
    <table width="60%" border="0" cellspacing="0" cellpadding="1">
      <tr bgcolor="#9999FF"> 
        <td width="50%" bgcolor="#6666FF"><font size="2" face="Verdana,
Arial, Helvetica, sans-serif" color="#FFFFFF"><b>Host 
          Information </b></font><font size="1" color="#6666ff">NQT20070309 
</font></td>
        <td bgcolor="#6666FF"><font size="2" face="Verdana, Arial,
Helvetica, sans-serif" color="#FFFFFF"><b>Host 
          Connectivity</b></font></td>
      </tr>
      <tr valign="top" bgcolor="#CCCCFF"> 
        <td> 
          <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
            <input type="radio" name="queryType" value="lookup">
            Resolve/Reverse Lookup<br>
            <input type="radio" name="queryType" value="dig">
            Get DNS Records<br>
            <input type="radio" name="queryType" value="wwwhois">
            Whois (Web)<br>
            <input type="radio" name="queryType" value="arin">
            Whois (IP owner)</font></p>
        </td>
        <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
          <input type="radio" name="queryType" value="checkp">
          Check port: 
          <input type="text" name="port" size="5" maxlength="5" value="80">
          <br>
          <input type="radio" name="queryType" value="p">
          Ping host<br>
          <input type="radio" name="queryType" value="tr">
          Traceroute to host<br>
          <input type="radio" name="queryType" value="all" checked>
          Do it all</font></td>
      </tr>
      
      </table>
  <table width="60%" border="0" cellspacing="0" cellpadding="1"><tr
  bgcolor="#9999FF"> 
        <td colspan="2">
          <div align="center">
            <input type="text" name="target" 
value="<?php echo isset($_REQUEST['target']) ? strip_tags($_REQUEST['target']) : 'Enter host or IP'?>" onFocus="m(this)">
            <input type="submit" name="Submit" value="Do It">
          </div>
        </td>
      </tr>
    </table>
  </form>
</div>

<?php
/* Controller logic begins here. */
require_once('NetworkQueryTool.php');

if ($_REQUEST['target']) {
  /* Create NQT object */
  $nqt = new NetworkQueryTool($_REQUEST['target']);
  
  /* Turn on debug output if requested */
  if ($debug == true) {
    $nqt->enableDebug(true);
  }
  
  /* Determine which activities to perform */
  if ($_REQUEST['queryType'] == 'lookup' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>Resolve</h4><blockquote><pre>';
    if (($resolved = $nqt->doResolveHost()) === false) {
      echo $nqt->getTarget() . ' could not be resolved.';
    } else {
      echo $nqt->getTarget() . ' resolves to ' . $nqt->doResolveHost();
    }
    echo '</pre></blockquote>';
    flush();
  }
  if ($_REQUEST['queryType'] == 'dig' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>DNS Query Results:</h5><blockquote><pre>' . $nqt->doDig()
       . '</pre></blockquote>';
    flush();
  }
  if ($_REQUEST['queryType'] == 'wwwhois' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>WWWhois Results:</h5><blockquote><pre>' . wordwrap($nqt->doWwwWhois(), 100)
         . '</pre></blockquote>';
    flush();
  }
  if ($_REQUEST['queryType'] == 'arin' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>RIR Whois Results:</h5><blockquote><pre>' . $nqt->doRirWhois()
         . '</pre></blockquote>';
    flush();
  }
  if ($_REQUEST['queryType'] == 'checkp' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>Check Port:</h5><blockquote><pre>';
    if (preg_match('|[^0-9]|', $_REQUEST['port'])) {
      echo 'Invalid port specified.';
    } else {
      echo $nqt->doCheckPort($_REQUEST['port']) ? 'Port ' . $_REQUEST['port'] . 
           ' is open' : 'Port ' . $_REQUEST['port'] . ' is closed';
    }
    echo '</pre></blockquote>';
    flush();
  }
  if ($_REQUEST['queryType'] == 'p' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>Ping Results:</h5><blockquote><pre>' . $nqt->doPing()
    . '</pre></blockquote>';
    flush();
  }
  if ($_REQUEST['queryType'] == 'tr' || $_REQUEST['queryType'] == 'all') {
    echo '<h4>Traceroute Results:</h5><blockquote><pre>' . $nqt->doTraceroute()
         . '</pre></blockquote>';
    flush();
  }
}
?>

<hr>
<p align="right"><font face="verdana,arial" size=1 color="#ffffff">NQT20070309
<a href="http://drunkwerks.com/software/php/nqt/"><font color="#cccccc">Network 
Query Tool 1.9</a><br>Copyright &copy; 2001-<?php echo date('Y');?>, Drunkwerks
</font></p>
</body>
</html>
